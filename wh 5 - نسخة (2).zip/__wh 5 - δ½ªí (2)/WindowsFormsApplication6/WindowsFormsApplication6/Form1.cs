﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            label4.Text = "+";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            label4.Text = "-";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            label4.Text = "*";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            label4.Text = "/";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (label4.Text == "+") { textBox3.Text = Convert.ToInt32(textBox1.Text) + Convert.ToInt32(textBox2.Text) + ""; }
            else if (label4.Text == "-") { textBox3.Text = Convert.ToInt32(textBox1.Text) - Convert.ToInt32(textBox2.Text) + ""; }
            else if (label4.Text == "*") { textBox3.Text = Convert.ToInt32(textBox1.Text) * Convert.ToInt32(textBox2.Text) + ""; }
            else
            {
                if (textBox2.Text == "0") { MessageBox.Show("enter anon_ZERO numper"); }
                else { textBox3.Text = Convert.ToInt32(textBox1.Text) / Convert.ToInt32(textBox2.Text) + ""; }

            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox1.Focus();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8) && (e.KeyChar != 46))
                e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8) && (e.KeyChar != 46))
                e.Handled = true;
        }
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }
    }
}
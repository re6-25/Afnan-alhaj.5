﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            player.Height -= 5;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            player.Left += 5;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Top = 0;
            this.Left = 0;
            this.Width = this.Width + 100;
            this.Height = this.Height + 100;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            player.Top -= 5;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            player.Height += 5;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            player.Width -= 5;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            player.Width -= 5;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            player.Left -= 5;

        }
        private void button7_Click(object sender, EventArgs e)
        {
            player.Top += 5;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = 0; bool f = false;
            Result.Text = null;
            if (checkBox1.Checked == true) { sum += Convert.ToInt32(checkBox1.Text); f = true; }
            if (checkBox2.Checked == true) { sum += Convert.ToInt32(checkBox2.Text); f = true; }
            if (checkBox3.Checked == true) { sum += Convert.ToInt32(checkBox3.Text); f = true; }
            if (checkBox4.Checked == true) { sum += Convert.ToInt32(checkBox4.Text); f = true; }
            if (checkBox5.Checked == true) { sum += Convert.ToInt32(checkBox5.Text); f = true; }
            if (f)
                Result.Text = sum.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (panel1.Visible == true)
                panel1.Visible =false;
            else
                panel1.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton8.Checked == true)
                label3.BackColor = Color.Red;
            if(radioButton7.Checked== true)
                label3.BackColor = Color.Yellow;
            if (radioButton6.Checked == true)
                label3.BackColor = Color.Green;
            if (radioButton5.Checked == true)
                label3.BackColor = Color.Blue;
            //----------------------------------------//
            if (radioButton1.Checked == true)
                label3.BackColor = Color.Red;

            if (radioButton2.Checked == true)
                label3.BackColor = Color.Yellow;

            if (radioButton3.Checked == true)
                label3.BackColor = Color.Green;

            if (radioButton4.Checked == true)
                label3.BackColor = Color.Blue;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (panel1.Enabled == true)
                panel1.Enabled = false;
            else
                panel1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
